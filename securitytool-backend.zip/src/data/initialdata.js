const sessionvulnerabilityinitialdata = {
    "Session does not expire on closing the browser": "Network Error Please Try Again",
    "Session time-out is high (or) not implemented.": "Network Error Please Try Again",
    "Session token being passed in other areas apart from cookies": "Network Error Please Try Again",
    "An adversary can hijack user sessions by session fixation": "Network Error Please Try Again",
    "Application is vulnerable to session hijacking attack": "Network Error Please Try Again",
  }

  module.exports = {sessionvulnerabilityinitialdata};