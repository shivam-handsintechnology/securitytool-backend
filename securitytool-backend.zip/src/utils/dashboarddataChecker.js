module.exports = {
    Session_time_out_is_high__not_implemented: [
        "Session is Infinite",
        "Session_time_out is High",
        "Session_time_out is Low",
        "Session_time_out is Normal",
        "Not Implemented"
    ]
}