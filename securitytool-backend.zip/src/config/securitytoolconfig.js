
const mongoURI="mongodb+srv://handsinsecurity:YxGDj8InSbMpXLia@cluster0.xvqvt5s.mongodb.net/security"
module.exports = {
    mongoURI,
  };