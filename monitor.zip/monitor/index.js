
// @desc: testing Applicaton
const testing = require('./src/testingData')
// @desc: Entry point of the application
const validateAndSetMiddleware = require('./src/middleware')
module.exports = { validateAndSetMiddleware, testing }

