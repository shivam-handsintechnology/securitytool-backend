module.exports={
    internetDbVpnCatcherApi:"https://internetdb.shodan.io/",
    
}