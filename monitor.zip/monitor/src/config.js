// exports.baseUrl = "https://securitytool.handsintechnology.in/api/client"
exports.baseUrl = "http://localhost:20000/api/client";