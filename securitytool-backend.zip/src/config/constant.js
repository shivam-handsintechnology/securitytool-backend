module.exports = {
  email: process.env.EMAIL,
  password: process.env.PASSWORD,
  internetDbVpnCatcherApi: "https://internetdb.shodan.io/",
};