module.exports = {
    googleClientID:
      "200245150083-cfgtfsupklmokrvvvfr30cdpvtf0lb6m.apps.googleusercontent.com",
    googleClientSecret: "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",
    mongoURI: "mongodb+srv://handsinsecurity:YxGDj8InSbMpXLia@cluster0.xvqvt5s.mongodb.net/security",
    cookieKey: "hsdghsdghsd",
    FACEBOOK_APP_ID: "GyFu8JttpR",
    FACEBOOK_APP_SECRET: "GyFu8JttpR",
    FRONTEND_HOST:"http://localhost:3000/"
  };